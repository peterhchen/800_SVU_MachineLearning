from pyspark import SparkContext 
# sc = SparkContext("local", "Accumulator app") 
# Get the Saprk Context
sc = SparkContext.getOrCreate()
# run Accumulattor on distrubted Node
num = sc.accumulator(10) 
def f(x): 
   global num 
   num+=x 
# Parallelized the RDD (Resilient Distributed Dataset)
rdd = sc.parallelize([20,30,40,50]) 
# foreach on distribued Node
rdd.foreach(f) 
# Get the result from ditributed Node
# https://spark.apache.org/docs/1.6.1/api/java/org/apache/spark/Accumulator.html
# spark accumulator.value
final = num.value 
print ("Accumulated value is -> %i" % (final))