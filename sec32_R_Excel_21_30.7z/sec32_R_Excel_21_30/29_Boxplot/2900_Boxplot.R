# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/29_Boxplot/"
setwd(path)
print (getwd())

input <- mtcars[,c('mpg','cyl')]
print(head(input))
# Give the chart file a name.
png(file = "boxplot.png")

# Plot the chart.
boxplot(mpg ~ cyl, data = mtcars, xlab = "Number of Cylinders",
   ylab = "Miles Per Gallon", main = "Mileage Data")

# Save the file.
dev.off()
