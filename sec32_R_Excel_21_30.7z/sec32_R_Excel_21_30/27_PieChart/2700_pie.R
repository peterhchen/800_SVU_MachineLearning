# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/27_PieChart/"
setwd(path)
print (getwd())
# Create data for the graph.
x <- c(21, 62, 10, 53)
labels <- c("London", "New York", "Singapore", "Mumbai")

# Give the chart file a name.
png(file = "city.png")

# Plot the chart.
pie(x,labels)

# Save the file.
dev.off()
