install.packages("odbc");require("odbc")

# Create a connection Object to MySQL database.
# https://dev.mysql.com/doc/sakila/en/
# Sakila is a sample database is the default database from MySQL

con <- dbConnect(odbc::odbc(), 
    .connection_string = "Driver={MySQL ODBC 8.0 Unicode Driver};",
    Server = "localhost", Database = "sakila", UID = "root", PWD = "Pc1997=ch",
    Port = 3306)

# https://www.rdocumentation.org/packages/DBI/versions/0.5-1/topics/dbListTables
dbListTables(con)
#  [1] "actor"                      "actor_info"                 "address"                    "category"                  
#  [5] "city"                       "country"                    "customer"                   "customer_list"             
#  [9] "film"                       "film_actor"                 "film_category"              "film_list"                 
# [13] "film_text"                  "inventory"                  "language"                   "nicer_but_slower_film_list"
# [17] "payment"                    "rental"                     "sales_by_film_category"     "sales_by_store"            
# [21] "staff"                      "staff_list"                 "store" 

# Query the "actor" tables to get all the rows.
# result <- dbSendQuery(con, "select * from actor")
# https://www.rdocumentation.org/packages/DBI/versions/0.5-1/topics/dbSendQuery
rs <- dbSendQuery(con, "select * from actor;")
dbFetch(rs)
dbClearResult(rs)
#     actor_id  first_name    last_name         last_update
# 1          1    PENELOPE      GUINESS 2006-02-15 04:34:33
# 2          2        NICK     WAHLBERG 2006-02-15 04:34:33
# 3          3          ED        CHASE 2006-02-15 04:34:33
# 4          4    JENNIFER        DAVIS 2006-02-15 04:34:33
# 5          5      JOHNNY LOLLOBRIGIDA 2006-02-15 04:34:33
# 6          6       BETTE    NICHOLSON 2006-02-15 04:34:33
# 7          7       GRACE       MOSTEL 2006-02-15 04:34:33
# 8          8     MATTHEW    JOHANSSON 2006-02-15 04:34:33
# 9          9         JOE        SWANK 2006-02-15 04:34:33
# 10        10   CHRISTIAN        GABLE 2006-02-15 04:34:33
# ...

dbDisconnect(con)