# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/24_JSON/"
setwd(path)
print (getwd())
# [1] "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/24_JSON"

# Install JSON packages
install.packages("RCurl")
install.packages("XML")
install.packages("stringr")
install.packages("plyr")

#https://rdrr.io/cran/XML/man/getHTMLLinks.html
# Read the URL.
#url <- "http://www.geos.ed.ac.uk/~weather/jcmb_ws/"
#url <- "http://www.omegahat.net"
url <- "https://www.geos.ed.ac.uk/~weather/jcmb_ws/"

try(links <-getHTMLLinks("http://www.omegahat.net"))
#   [1] "http://omegahat.wordpress.com/"                                                            
#   [2] "contents.html"                                                                             
#   [3] "cranRepository.html"                                                                       
#   [4] "Papers/index.html"                                                                         
#   [5] "http://www.omegahat.net/R/src/contrib"                                                     
#   [6] "RFirefox"                                                                                  
#   [7] "RKML"                                                                                      
#   [8] "RKML/JSM2011/README.html"                                                                  
#   [9] "http://www.amstat.org/meetings/jsm/2011/onlineprogram/ActivityDetails.cfm?SessionID=206267"
#  [10] "RGoogleStorage"                                  
#try(getHTMLLinks("http://www.omegahat.net/RSXML"))
#try(unique(getHTMLExternalFiles("http://www.omegahat.net"))
print(links)
#   [1] "http://omegahat.wordpress.com/"                                                            
#   [2] "contents.html"                                                                             
#   [3] "cranRepository.html"                                                                       
# ...
# [134] "http://www.cmis.csiro.au/bill.venables/"                                                   
# [135] "http://www.omegahat.net/mailman/listinfo/"                                                 
# [136] "mailto:omega-devel@omegahat.net"                                                           
# [137] "contrib/RS-DBI/index.html"                                                                 
# [138] "contrib/index.html"  






# Below is not working.
# # Gather the html links present in the webpage.
# links <- getHTMLLinks(url)
# # Warning message:
# # XML content does not seem to be XML: '' 
# # Setup file names to the JCMB_2015 files. 
# filenames <- links[str_detect(links, "JCMB_2015")]
# # Error in str_detect(links, "JCMB_2015") : 
# #   could not find function "str_detect"

# # Store the file names as a list.
# filenames_list <- as.list(filenames)

# # Create a function to download the files by passing the URL and filename list.
# downloadcsv <- function (mainurl,filename) {
#    filedetails <- str_c(mainurl,filename)
#    download.file(filedetails,filename)
# }

# # Now apply the l_ply function and save the files into the current R working directory.
# l_ply(filenames,downloadcsv,mainurl = "http://www.geos.ed.ac.uk/~weather/jcmb_ws/")