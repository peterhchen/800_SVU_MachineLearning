# Install package
install.packages("xlsx")
# Verify the package is installed.
any(grepl("xlsx",installed.packages()))
# [1] TRUE
# Load the library into R workspace.
library("xlsx")

path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/21_Excel/"
name <- "input.xlsx"
pname <- paste (path, name, sep ="")
# Read the first worksheet in the file input.xlsx.
data <- read.xlsx(pname, sheetIndex = 1)
print(data)
#   id     name salary start_date       dept
# 1  1    Peter 120000 2012-01-01         IT
# 2  2    Jason 100000 2020-09-23  Opeartion
# 3  3 Jobathan 100000 2021-01-02 Programmer
# 4  4    Peter 120000 2012-01-01         IT
# 5  5    Peter 120000 2012-01-01         IT
# 6  6    Peter 120000 2012-01-01         IT
# 7  7    Peter 120000 2012-01-01         IT
# 8  8    Peter 120000 2012-01-01         IT