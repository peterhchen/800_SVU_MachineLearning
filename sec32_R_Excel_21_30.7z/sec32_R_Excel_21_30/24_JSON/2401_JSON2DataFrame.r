path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/24_JSON/"
# mtcars (motor trend of cars)
rname <- "input.json"
prname <- paste (path, rname, sep ="")
# Install JSON packages
install.packages("rjson")

# Load the package required to read JSON files.
library("rjson")

# Give the input file name to the function.
result <- fromJSON(file = prname)

# Convert JSON file to a data frame.
json_data_frame <- as.data.frame(result)

print(json_data_frame)
#   ID     Name Salary  StartDate       Dept
# 1  1     Rick  623.3   1/1/2012         IT
# 2  2      Dan  515.2  9/23/2013 Operations
# 3  3 Michelle    611 11/15/2014         IT
# 4  4     Ryan    729  5/11/2014         HR
# 5  5     Gary 843.25  3/27/2015    Finance
# 6  6     Nina    578  5/21/2013         IT
# 7  7    Simon  632.8  7/30/2013 Operations
# 8  8     Guru  722.5  6/17/2014    Finance
