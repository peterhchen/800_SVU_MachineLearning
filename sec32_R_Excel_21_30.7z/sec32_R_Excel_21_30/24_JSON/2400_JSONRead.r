path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/24_JSON/"
# mtcars (motor trend of cars)
rname <- "input.json"
prname <- paste (path, rname, sep ="")
# Install JSON packages
install.packages("rjson")

# Load the package required to read JSON files.
library("rjson")

# Give the input file name to the function.
result <- fromJSON(file = prname)

# Print the result.
print(result)
# $ID
# [1] "1" "2" "3" "4" "5" "6" "7" "8"

# $Name
# [1] "Rick"     "Dan"      "Michelle" "Ryan"     "Gary"     "Nina"     "Simon"    "Guru"    

# $Salary
# [1] "623.3"  "515.2"  "611"    "729"    "843.25" "578"    "632.8"  "722.5" 

# $StartDate
# [1] "1/1/2012"   "9/23/2013"  "11/15/2014" "5/11/2014"  "3/27/2015"  "5/21/2013"  "7/30/2013"  "6/17/2014" 

# $Dept
# [1] "IT"         "Operations" "IT"         "HR"         "Finance"    "IT"         "Operations" "Finance" 