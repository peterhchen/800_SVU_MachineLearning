path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/22_Binary/"
# mtcars (motor trend of cars)
rname <- "mtcars.csv"
prname <- paste (path, rname, sep ="")
wname <- "mtcars.dat"
pwname <- paste (path, wname, sep ="")

# # Read the "mtcars.csv" (motor-trend of cars) file and store only the columns 
# #   "cyl", "am (auto/manual)" and "gear".
# # Read csv for verificaiton only.
# data <- read.csv(prname)
# print(data)
# #   cyl am gear
# # 1   6  1    4
# # 2   6  1    4
# # 3   4  1    4
# # 4   6  0    3
# # 5   8  0    3

# Read from csv into a table
# Store 5 records from the csv file as a new data frame.
new.mtcars <- read.table(prname, sep = ",", header = TRUE, nrows = 5)

# Create a connection object to write the binary file using mode "wb".
write.filename = file(pwname, "wb")

# Write the column names of the data frame to the connection object.
writeBin(colnames(new.mtcars), write.filename)

# Write the records in each of the column to the file.
writeBin(c(new.mtcars$cyl,new.mtcars$am,new.mtcars$gear), write.filename)

# Close the file for writing so that it can be read by other program.
close(write.filename)
