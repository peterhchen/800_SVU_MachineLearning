path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/22_Binary/"
wname <- "mtcars.dat"
pwname <- paste (path, wname, sep ="")

# Create a connection object to read the file in binary mode using "rb".
read.filename <- file(pwname, "rb")

# First read the column names. n = 3 as we have 3 columns.
column.names <- readBin(read.filename, character(),  n = 3)

# Next read the column values. 
# n = 18 as we have 3 column names and 15 values.
read.filename <- file(pwname, "rb")
bindata <- readBin(read.filename, integer(),  n = 18)

# Print the data.
print(bindata)
#  [1]    7108963 1728081249    7496037          
#   6          6          4          6          8
#   1          1          1
# [12]          0          0          
# 4          4          4          3          3

# Read the values from 4th byte to 8th byte which represents "cyl".
cyldata = bindata[4:8]
print(cyldata)
#[1] 6 6 4 6 8

# Read the values form 9th byte to 13th byte which represents "am".
amdata = bindata[9:13]
print(amdata)
#[1] 1 1 1 0 0

# Read the values form 9th byte to 13th byte which represents "gear".
geardata = bindata[14:18]
print(geardata)
# [1] 4 4 4 3 3
# Combine all the read values to a dat frame.
finaldata = cbind(cyldata, amdata, geardata)
print(column.names)
# [1] "cyl"  "am"   "gear"
colnames(finaldata) = column.names
print(finaldata)
#      cyl am gear
# [1,]   6  1    4
# [2,]   6  1    4
# [3,]   4  1    4
# [4,]   6  0    3
# [5,]   8  0    3