
# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/30_Histogram/"
setwd(path)
print (getwd())

# Create data for the graph.
v <-  c(9,13,21,8,36,22,12,41,31,33,19)

# Give the chart file a name.
png(file = "histogram.png")

# Create the histogram.
hist(v,xlab = "Weight",col = "yellow",border = "blue")

# Save the file.
dev.off()
