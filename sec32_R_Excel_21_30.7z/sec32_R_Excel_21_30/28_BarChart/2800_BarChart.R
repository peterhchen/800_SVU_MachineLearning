# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/28_BarChart/"
setwd(path)
print (getwd())
# Create the data for the chart
H <- c(7,12,28,3,41)

# Give the chart file a name
png(file = "barchart.png")

# Plot the bar chart 
barplot(H)

# Save the file
dev.off()