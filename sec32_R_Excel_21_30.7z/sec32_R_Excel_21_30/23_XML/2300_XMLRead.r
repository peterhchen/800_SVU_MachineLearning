path <- "C:/Work/SVU/800_SVU_MachineLearning/sec32_R_Excel_21_30/23_XML/"
# mtcars (motor trend of cars)
rname <- "input.xml"
prname <- paste (path, rname, sep ="")
# Install XML packages
install.packages("xml2")
# Load the package required to read XML files.
library("xml2")

# Also load the other required package.
#library("methods")

# Give the input file name to the function.
result <- xmlParse(file = prname)

# Print the result.
print(result)

# <?xml version="1.0"?>
# <RECORDS>
#   <EMPLOYEE>
#     <ID>1</ID>
#     <NAME>Rick</NAME>
#     <SALARY>623.3</SALARY>
#     <STARTDATE>1/1/2012</STARTDATE>
#     <DEPT>IT</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>2</ID>
#     <NAME>Dan</NAME>
#     <SALARY>515.2</SALARY>
#     <STARTDATE>9/23/2013</STARTDATE>
#     <DEPT>Operations</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>3</ID>
#     <NAME>Michelle</NAME>
#     <SALARY>611</SALARY>
#     <STARTDATE>11/15/2014</STARTDATE>
#     <DEPT>IT</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>4</ID>
#     <NAME>Ryan</NAME>
#     <SALARY>729</SALARY>
#     <STARTDATE>5/11/2014</STARTDATE>
#     <DEPT>HR</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>5</ID>
#     <NAME>Gary</NAME>
#     <SALARY>843.25</SALARY>
#     <STARTDATE>3/27/2015</STARTDATE>
#     <DEPT>Finance</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>6</ID>
#     <NAME>Nina</NAME>
#     <SALARY>578</SALARY>
#     <STARTDATE>5/21/2013</STARTDATE>
#     <DEPT>IT</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>7</ID>
#     <NAME>Simon</NAME>
#     <SALARY>632.8</SALARY>
#     <STARTDATE>7/30/2013</STARTDATE>
#     <DEPT>Operations</DEPT>
#   </EMPLOYEE>
#   <EMPLOYEE>
#     <ID>8</ID>
#     <NAME>Guru</NAME>
#     <SALARY>722.5</SALARY>
#     <STARTDATE>6/17/2014</STARTDATE>
#     <DEPT>Finance</DEPT>
#   </EMPLOYEE>
# </RECORDS>

xml_data <- xmlToList(result)
print(xml_data)
# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "1"

# $EMPLOYEE$NAME
# [1] "Rick"

# $EMPLOYEE$SALARY
# [1] "623.3"

# $EMPLOYEE$STARTDATE
# [1] "1/1/2012"

# $EMPLOYEE$DEPT
# [1] "IT"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "2"

# $EMPLOYEE$NAME
# [1] "Dan"

# $EMPLOYEE$SALARY
# [1] "515.2"

# $EMPLOYEE$STARTDATE
# [1] "9/23/2013"

# $EMPLOYEE$DEPT
# [1] "Operations"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "3"

# $EMPLOYEE$NAME
# [1] "Michelle"

# $EMPLOYEE$SALARY
# [1] "611"

# $EMPLOYEE$STARTDATE
# [1] "11/15/2014"

# $EMPLOYEE$DEPT
# [1] "IT"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "4"

# $EMPLOYEE$NAME
# [1] "Ryan"

# $EMPLOYEE$SALARY
# [1] "729"

# $EMPLOYEE$STARTDATE
# [1] "5/11/2014"

# $EMPLOYEE$DEPT
# [1] "HR"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "5"

# $EMPLOYEE$NAME
# [1] "Gary"

# $EMPLOYEE$SALARY
# [1] "843.25"

# $EMPLOYEE$STARTDATE
# [1] "3/27/2015"

# $EMPLOYEE$DEPT
# [1] "Finance"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "6"

# $EMPLOYEE$NAME
# [1] "Nina"

# $EMPLOYEE$SALARY
# [1] "578"

# $EMPLOYEE$STARTDATE
# [1] "5/21/2013"

# $EMPLOYEE$DEPT
# [1] "IT"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "7"

# $EMPLOYEE$NAME
# [1] "Simon"

# $EMPLOYEE$SALARY
# [1] "632.8"

# $EMPLOYEE$STARTDATE
# [1] "7/30/2013"

# $EMPLOYEE$DEPT
# [1] "Operations"


# $EMPLOYEE
# $EMPLOYEE$ID
# [1] "8"

# $EMPLOYEE$NAME
# [1] "Guru"

# $EMPLOYEE$SALARY
# [1] "722.5"

# $EMPLOYEE$STARTDATE
# [1] "6/17/2014"

# $EMPLOYEE$DEPT
# [1] "Finance"
