# Create two vectors of different lengths.
vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)
# Take these vectors as input to the array.
array1 <- array(c(vector1,vector2),dim = c(3,3,2))
print(vector1)
# [1] 5 9 3
print(vector2)
# [1] 10 11 12 13 14 15
print(array1)
# , , 1
#      [,1] [,2] [,3]
# [1,]    5   10   13
# [2,]    9   11   14
# [3,]    3   12   15

# , , 2
#      [,1] [,2] [,3]
# [1,]    5   10   13
# [2,]    9   11   14
# [3,]    3   12   15
# Create two vectors of different lengths.
vector3 <- c(9,1,0)
vector4 <- c(6,0,11,3,14,1,2,6,9)
array2 <- array(c(vector3,vector4),dim = c(3,3,2))
print(array2)
# , , 1
#      [,1] [,2] [,3]
# [1,]    9    6    3
# [2,]    1    0   14
# [3,]    0   11    1

# , , 2
#      [,1] [,2] [,3]
# [1,]    2    9    6
# [2,]    6    1    0
# [3,]    9    0   11

# create matrices from these arrays.
matrix1 <- array1[,,2]
matrix2 <- array2[,,2]
print(matrix1)
#      [,1] [,2] [,3]
# [1,]    5   10   13
# [2,]    9   11   14
# [3,]    3   12   15
print(matrix2)
#      [,1] [,2] [,3]
# [1,]    2    9    6
# [2,]    6    1    0
# [3,]    9    0   11
# Add the matrices.
result <- matrix1+matrix2
print(result)
#      [,1] [,2] [,3]
# [1,]    7   19   19
# [2,]   15   12   14
# [3,]   12   12   26