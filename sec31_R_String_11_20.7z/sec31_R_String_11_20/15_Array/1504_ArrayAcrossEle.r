# Create two vectors of different lengths.
vector1 <- c(5,9,3)
vector2 <- c(10,11,12,13,14,15)

# Take these vectors as input to the array.
new.array <- array(c(vector1,vector2),dim = c(3,3,2))
print(new.array)

# , , 1

#      [,1] [,2] [,3]
# [1,]    5   10   13
# [2,]    9   11   14
# [3,]    3   12   15

# , , 2

#      [,1] [,2] [,3]
# [1,]    5   10   13
# [2,]    9   11   14
# [3,]    3   12   15

# X is an array or a matrix if the dimension of the array is 2;
# MARGIN is a variable defining how the function is applied: 
# when MARGIN=1, it applies over rows, whereas with MARGIN=2, it works over columns. 
# Note that when you use the construct MARGIN=c(1,2), 
# it applies to both rows and columns; and
# FUN, which is the function that you want to apply to the data. 
# It can be any R function, including a User Defined Function (UDF).
# Use apply to calculate the sum of the rows across all the matrices.
result <- apply(new.array, c(1), sum)
print(c(1))
# [1] 1
print(result)
# [1] 56 68 60