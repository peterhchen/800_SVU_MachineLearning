a <- "Hello"
b <- 'How'
c <- "are you? "

print(paste(a,b,c))
# [1] "Hello How are you? "
print(paste(a,b,c, sep = "-"))
# [1] "Hello-How-are you? "
print(paste(a,b,c, sep = "", collapse = ""))
#[1] "HelloHoware you? "


# Total number of digits displayed. Last digit rounded off.
result <- format(23.123456789, digits = 9)
print(result)
# [1] "23.1234568"

# Display numbers in scientific notation.
result <- format(c(6, 13.14521), scientific = TRUE)
print(result)
# [1] "6.000000e+00" "1.314521e+01"

# The minimum number of digits to the right of the decimal point.
result <- format(23.47, nsmall = 5)
print(result)
# [1] "23.47000"

# Format treats everything as a string.
result <- format(6)
print(result)
# [1] "6"

# Numbers are padded with blank in the beginning for width.
result <- format(13.7, width = 6)
print(result)
# [1] "  13.7"

# Left justify strings.
result <- format("Hello", width = 8, justify = "l")
print(result)
# [1] "Hello   "

# Justfy string with center.
result <- format("Hello", width = 8, justify = "c")
print(result)
# [1] " Hello  "

# Number of characters.
result <- nchar("Count the number of characters")
print(result)
# [1] 30


# Changing to Upper case.
result <- toupper("Changing To Upper")
print(result)
# [1] "CHANGING TO UPPER"

# Changing to lower case.
result <- tolower("Changing To Lower")
print(result)
# [1] "changing to lower"

# SubString
# Extract characters from 5th to 7th position.
result <- substring("Extract", 5, 7)
print(result)
# [1] "act"