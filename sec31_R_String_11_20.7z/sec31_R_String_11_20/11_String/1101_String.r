# Valid String
a <- 'Start and end with single quote'
print(a)
# [1] "Start and end with single quote"

b <- "Start and end with double quotes"
print(b)
# [1] "Start and end with double quotes"

c <- "single quote ' in between double quotes"
print(c)
# [1] "single quote ' in between double quotes"

d <- 'Double quotes " in between single quote'
print(d)
[1] "Double quotes \" in between single quote"

# invalid string
# e <- 'Mixed quotes" 
# print(e)

# f <- 'Single quote ' inside single quote'
# print(f)
# d <- 'Double quotes " in between single quote'

# g <- "Double quotes " inside double quotes"
# print(g)