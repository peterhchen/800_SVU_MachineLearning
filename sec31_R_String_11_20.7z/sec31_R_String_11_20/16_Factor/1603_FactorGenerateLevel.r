# Genereate Level
# gl(n, k, labels)
# Following is the description of the parameters used −

# n is a integer giving the number of levels.

# k is a integer giving the number of replications.

# labels is a vector of labels for the resulting factor levels.
v <- gl(3, 4, labels = c("Tampa", "Seattle","Boston"))
print(v)
#  [1] Tampa   Tampa   Tampa   Tampa   Seattle Seattle Seattle Seattle Boston  Boston  Boston  Boston 
# Levels: Tampa Seattle Boston
