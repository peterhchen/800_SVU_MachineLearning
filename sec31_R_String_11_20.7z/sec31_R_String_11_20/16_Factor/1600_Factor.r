# Create a vector as input.
data <- c("East","West","East","North","North","East","West","West","West","East","North")

print(data)
#  [1] "East"  "West"  "East"  "North" "North" "East"  "West"  "West"  "West" 
# [10] "East"  "North"
print(is.factor(data))
# [1] FALSE

# Apply the factor function.
factor_data <- factor(data)

print(factor_data)
#  [1] East  West  East  North North East  West  West  West  East  North
# Levels: East North West

print(is.factor(factor_data))
# [1] TRUE