# Create the vectors for data frame.
height <- c(132,151,162,139,166,147,122)
weight <- c(48,49,66,53,67,52,40)
gender <- c("male","male","female","female","male","female","male")
gender <- factor(gender)

# Create the data frame.
input_data <- data.frame(height,weight,gender)
print(input_data)
#   height weight gender
# 1    132     48   male
# 2    151     49   male
# 3    162     66 female
# 4    139     53 female
# 5    166     67   male
# 6    147     52 female
# 7    122     40   male

# Test if the gender column is a factor.
print(is.factor(input_data$gender))
# [1] TRUE

# Print the gender column so see the levels.
print(input_data$gender)
#[1] male   male   female female male   female male  
#Levels: female male