# Create the data frame.
emp.data <- data.frame(
   emp_id = c (1:5), 
   emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
   salary = c(623.3,515.2,611.0,729.0,843.25), 
   
   start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
      "2015-03-27")),
   stringsAsFactors = FALSE
)
# Get the structure of the data frame.
str(emp.data)
# 'data.frame':   5 obs. of  4 variables:
#  $ emp_id    : int  1 2 3 4 5
#  $ emp_name  : chr  "Rick" "Dan" "Michelle" "Ryan" ...
#  $ salary    : num  623 515 611 729 843
#  $ start_date: Date, format: "2012-01-01" "2013-09-23" "2014-11-15" "2014-05-11" ...