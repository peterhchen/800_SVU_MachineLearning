# Create the data frame.
emp.data <- data.frame(
   emp_id = c (1:5),
   emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
   salary = c(623.3,515.2,611.0,729.0,843.25),
   
   start_date = as.Date(c("2012-01-01","2013-09-23","2014-11-15","2014-05-11",
      "2015-03-27")),
   stringsAsFactors = FALSE
)
# Extract Specific columns.
result <- data.frame(emp.data$emp_name,emp.data$salary)
print(result)
#   emp.data.emp_name emp.data.salary
# 1              Rick          623.30
# 2               Dan          515.20
# 3          Michelle          611.00
# 4              Ryan          729.00
# 5              Gary          843.25


# Extract First two rows:
# Create the data frame.
emp.data <- data.frame(
   emp_id = c (1:5),
   emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
   salary = c(623.3,515.2,611.0,729.0,843.25),
   
   start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
      "2015-03-27")),
   stringsAsFactors = FALSE
)
# Extract first two rows.
result <- emp.data[1:2,]
print(result)
#   emp_id emp_name salary start_date
# 1      1     Rick  623.3 2012-01-01
# 2      2      Dan  515.2 2013-09-23



# Extract 3rd and 5th row with 2nd and 4th column
# Create the data frame.
emp.data <- data.frame(
   emp_id = c (1:5), 
   emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
   salary = c(623.3,515.2,611.0,729.0,843.25), 
   
	start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
      "2015-03-27")),
   stringsAsFactors = FALSE
)

print(emp.data)
#   emp_id emp_name salary start_date
# 1      1     Rick 623.30 2012-01-01
# 2      2      Dan 515.20 2013-09-23
# 3      3 Michelle 611.00 2014-11-15
# 4      4     Ryan 729.00 2014-05-11
# 5      5     Gary 843.25 2015-03-27

# Extract 3rd and 5th row with 2nd and 4th column.
result <- emp.data[c(3,5),c(2,4)]
print(result)
#   emp_name start_date
# 3 Michelle 2014-11-15
# 5     Gary 2015-03-27
