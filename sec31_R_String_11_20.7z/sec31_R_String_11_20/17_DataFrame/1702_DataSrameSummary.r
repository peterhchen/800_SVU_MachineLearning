# Create the data frame.
emp.data <- data.frame(
   emp_id = c (1:5), 
   emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
   salary = c(623.3,515.2,611.0,729.0,843.25), 
   
   start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
      "2015-03-27")),
   stringsAsFactors = FALSE
)
# Print the summary.
print(summary(emp.data)) 
#      emp_id    emp_name             salary        start_date        
#  Min.   :1   Length:5           Min.   :515.2   Min.   :2012-01-01  
#  1st Qu.:2   Class :character   1st Qu.:611.0   1st Qu.:2013-09-23  
#  Median :3   Mode  :character   Median :623.3   Median :2014-05-11  
#  Mean   :3                      Mean   :664.4   Mean   :2014-01-14  
#  3rd Qu.:4                      3rd Qu.:729.0   3rd Qu.:2014-11-15  
#  Max.   :5                      Max.   :843.2   Max.   :2015-03-27 