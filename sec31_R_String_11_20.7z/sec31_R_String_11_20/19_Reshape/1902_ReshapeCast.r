# Load Pakcages MASS (Modern Spplaied Statitics for S)
library(MASS)
# library ships
print(ships)
#    type year period service incidents
# 1     A   60     60     127         0
# 2     A   60     75      63         0
# 3     A   65     60    1095         3
# ...
# 39    E   75     60       0         0
# 40    E   75     75     542         1

# Melt data
library(reshape)
molten.ships <- melt(data=ships, id = c("type","year"))
print(molten.ships)
#     type year  variable value
# 1      A   60    period    60
# 2      A   60    period    75
# 3      A   65    period    60
#...
# 39     E   75    period    60
# 40     E   75    period    75
# 41     A   60   service   127
# 42     A   60   service    63
# 43     A   65   service  1095
# ...
# 79     E   75   service     0
# 80     E   75   service   542
# 81     A   60 incidents     0
# 82     A   60 incidents     0
# # 83     A   65 incidents     3
# ...
# 118    E   70 incidents    12
# 119    E   75 incidents     0
# 120    E   75 incidents     1

# We can cast the molten data into a new form where the aggregate of each type of 
# ship for each year is created. 
# It is done using the cast() function.
library(reshape)
recasted.ship <- cast(molten.ships, type+year~variable,sum)
print(recasted.ship)
#    type year period service incidents
# 1     A   60    135     190         0
# 2     A   65    135    2190         7
# 3     A   70    135    4865        24
# 4     A   75    135    2244        11
# 5     B   60    135   62058        68
# 6     B   65    135   48979       111
# 7     B   70    135   20163        56
# 8     B   75    135    7117        18
# 9     C   60    135    1731         2
# 10    C   65    135    1457         1
# 11    C   70    135    2731         8
# 12    C   75    135     274         1
# 13    D   60    135     356         0
# 14    D   65    135     480         0
# 15    D   70    135    1557        13
# 16    D   75    135    2051         4
# 17    E   60    135      45         0
# 18    E   65    135    1226        14
# 19    E   70    135    3318        17
# 20    E   75    135     542         1