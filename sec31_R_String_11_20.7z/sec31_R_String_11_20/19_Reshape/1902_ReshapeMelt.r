# Load Pakcages MASS (Modern Spplaied Statitics for S)
library(MASS)
# library ships
print(ships)
#    type year period service incidents
# 1     A   60     60     127         0
# 2     A   60     75      63         0
# 3     A   65     60    1095         3
# ...
# 39    E   75     60       0         0
# 40    E   75     75     542         1

# Melt data
library(reshape)
molten.ships <- melt(data=ships, id = c("type","year"))
print(molten.ships)
#     type year  variable value
# 1      A   60    period    60
# 2      A   60    period    75
# 3      A   65    period    60
#...
# 39     E   75    period    60
# 40     E   75    period    75
# 41     A   60   service   127
# 42     A   60   service    63
# 43     A   65   service  1095
# ...
# 79     E   75   service     0
# 80     E   75   service   542
# 81     A   60 incidents     0
# 82     A   60 incidents     0
# # 83     A   65 incidents     3
# ...
# 118    E   70 incidents    12
# 119    E   75 incidents     0
# 120    E   75 incidents     1