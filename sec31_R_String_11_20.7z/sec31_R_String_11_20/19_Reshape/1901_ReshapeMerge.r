# Load Package MASS (Modern Applied Statistices with S)
# R is based on S Language.
library(MASS)

# https://stat.ethz.ch/R-manual/R-devel/library/MASS/html/Pima.tr.html
# Pima Indian heritage and living near Phoenix, Arizona, was tested for diabetes according to 
# World Health Organization criteria.
merged.Pima <- merge(x = Pima.te, y = Pima.tr,
   by.x = c("bp", "bmi"),
   by.y = c("bp", "bmi")
)
print(merged.Pima)
#    bp  bmi npreg.x glu.x skin.x ped.x age.x type.x npreg.y glu.y skin.y ped.y age.y type.y
# 1  60 33.8       1   117     23 0.466    27     No       2   125     20 0.088    31     No
# 2  64 29.7       2    75     24 0.370    33     No       2   100     23 0.368    21     No
# 3  64 31.2       5   189     33 0.583    29    Yes       3   158     13 0.295    24     No
# 4  64 33.2       4   117     27 0.230    24     No       1    96     27 0.289    21     No
# 5  66 38.1       3   115     39 0.150    28     No       1   114     36 0.289    21     No
# 6  68 38.5       2   100     25 0.324    26     No       7   129     49 0.439    43    Yes
# 7  70 27.4       1   116     28 0.204    21     No       0   124     20 0.254    36    Yes
# 8  70 33.1       4    91     32 0.446    22     No       9   123     44 0.374    40     No
# 9  70 35.4       9   124     33 0.282    34     No       6   134     23 0.542    29    Yes
# 10 72 25.6       1   157     21 0.123    24     No       4    99     17 0.294    28     No
# 11 72 37.7       5    95     33 0.370    27     No       6   103     32 0.324    55     No
# 12 74 25.9       9   134     33 0.460    81     No       8   126     38 0.162    39     No
# 13 74 25.9       1    95     21 0.673    36     No       8   126     38 0.162    39     No
# 14 78 27.6       5    88     30 0.258    37     No       6   125     31 0.565    49    Yes
# 15 78 27.6      10   122     31 0.512    45     No       6   125     31 0.565    49    Yes
# 16 78 39.4       2   112     50 0.175    24     No       4   112     40 0.236    38     No
# 17 88 34.5       1   117     24 0.403    40    Yes       4   127     11 0.598    28     No

nrow(merged.Pima)
# [1] 17