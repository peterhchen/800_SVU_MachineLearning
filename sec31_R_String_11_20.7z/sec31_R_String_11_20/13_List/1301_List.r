# Create a list containing strings, numbers, vectors and a logical
# values.
list_data <- list("Red", "Green", c(21,32,11), TRUE, 51.23, 119.1)
print(list_data)
# [[1]]
# [1] "Red"

# [[2]]
# [1] "Green"

# [[3]]
# [1] 21 32 11

# [[4]]
# [1] TRUE

# [[5]]
# [1] 51.23

# [[6]]
# [1] 119.1
