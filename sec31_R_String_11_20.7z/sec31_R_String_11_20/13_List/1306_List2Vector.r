Live Demo
# Create lists.
list1 <- list(1:5)
print(list1)
# [[1]]
# [1] 1 2 3 4 5

list2 <-list(10:14)
print(list2)
# [[1]]
# [1] 10 11 12 13 14

# Convert the lists to vectors.
v1 <- unlist(list1)
v2 <- unlist(list2)

print(v1)
# [1] 1 2 3 4 5
print(v2)
# [1] 10 11 12 13 14

# Now add the vectors
result <- v1+v2
print(result)
# [1] 11 13 15 17 19