# Create a list containing a vector, a matrix and a list.
list_data <- list(c("Jan","Feb","Mar"), matrix(c(3,9,5,1,-2,8), nrow = 2),
   list("green",12.3))

# Give names to the elements in the list.
names(list_data) <- c("1st Quarter", "A_Matrix", "A Inner list")

# Add element at the end of the list.
list_data[4] <- "New element"
print(list_data[4])
# [[1]]
# [1] "New element"

# Remove the last element.
list_data[4] <- NULL

# Print the 4th Element.
print(list_data[4])
# $<NA>
# NULL

# Update the 3rd Element.
list_data[3] <- "updated element"
print(list_data[3])
# $`A Inner list`
# [1] "updated element"