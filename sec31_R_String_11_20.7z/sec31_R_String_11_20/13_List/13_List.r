list1 <- list(c(2, 5, 3), 21.3, sin)
print(list1)