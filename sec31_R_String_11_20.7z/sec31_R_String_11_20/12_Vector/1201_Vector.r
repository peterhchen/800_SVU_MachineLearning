# Single element vector.
# Atomic vector of type character.
print("abc");
# [1] "abc"

# Atomic vector of type double.
print(12.5)
# [1] 12.5

# Atomic vector of type integer.
print(63L)
# [1] 63

# Atomic vector of type logical.
print(TRUE)
# [1] TRUE

# Atomic vector of type complex.
print(2+3i)
# [1] 2+3i

# Atomic vector of type raw.
print(charToRaw('hello'))
# [1] 68 65 6c 6c 6f
