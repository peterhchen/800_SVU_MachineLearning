# Vector element recycle.
v1 <- c(3,8,4,5,0,11)
v2 <- c(4,11)
# V2 becomes c(4,11,4,11,4,11)

add.result <- v1+v2
print(add.result)
# [1]  7 19  8 16  4 22

sub.result <- v1-v2
print(sub.result)
# [1] -1 -3  0 -6 -4  0
