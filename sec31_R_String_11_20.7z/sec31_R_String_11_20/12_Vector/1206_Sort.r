v <- c(3,8,4,5,0,11, -9, 304)

# Sort the elements of the vector.
sort.result <- sort(v)
print(sort.result)
# [1]  -9   0   3   4   5   8  11 304

# Sort the elements in the reverse order.
revsort.result <- sort(v, decreasing = TRUE)
print(revsort.result)
# [1] 304  11   8   5   4   3   0  -9

# Sorting character vectors.
v <- c("Red","Blue","yellow","violet")
sort.result <- sort(v)
print(sort.result)
# [1] "Blue"   "Red"    "violet" "yellow"

# Sorting character vectors in reverse order.
revsort.result <- sort(v, decreasing = TRUE)
print(revsort.result)
#[1] "yellow" "violet" "Red"    "Blue"