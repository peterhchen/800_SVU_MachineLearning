# Creating a sequence from 5 to 13.
v <- 5:13
print(v)
# [1]  5  6  7  8  9 10 11 12 13

# Creating a sequence from 6.6 to 12.6.
v <- 6.6:12.6
print(v)
# [1]  6.6  7.6  8.6  9.6 10.6 11.6 12.6

# If the final element specified does not belong to the sequence then it is discarded.
v <- 3.8:11.4
print(v)
# [1]  3.8  4.8  5.8  6.8  7.8  8.8  9.8 10.8

# seq()
# Create vector with elements from 5 to 9 incrementing by 0.4.
print(seq(5, 9, by = 0.4))
#  [1] 5.0 5.4 5.8 6.2 6.6 7.0 7.4 7.8 8.2 8.6 9.0

# The logical and numeric values are converted to characters.
s <- c('apple','red',5,TRUE)
print(s)
# [1] "apple" "red"   "5"     "TRUE" 