apple <- c('red', 'green', 'yellow')
print(apple)

print(class(apple))