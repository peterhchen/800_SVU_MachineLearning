# Create two vectors.
v1 <- c(3,8,4,5,0,11)
v2 <- c(4,11,0,8,1,2)

# Vector addition.
add.result <- v1+v2
print(add.result)
# [1]  7 19  4 13  1 13

# Vector subtraction.
sub.result <- v1-v2
print(sub.result)
# [1] -1 -3  4 -3 -1  9

# Vector multiplication.
multi.result <- v1*v2
print(multi.result)
# [1] 12 88  0 40  0 22

# Vector division.
divi.result <- v1/v2
print(divi.result)
# [1] 0.7500000 0.7272727       Inf 0.6250000 0.0000000 5.5000000
