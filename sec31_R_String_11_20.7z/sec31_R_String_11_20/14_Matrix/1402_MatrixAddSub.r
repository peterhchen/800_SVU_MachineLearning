# Create two 2x3 matrices.
matrix1 <- matrix(c(3, 9, -1, 4, 2, 6), nrow = 2)
print(matrix1)
#      [,1] [,2] [,3]
# [1,]    3   -1    2
# [2,]    9    4    6

matrix2 <- matrix(c(5, 2, 0, 9, 3, 4), nrow = 2)
print(matrix2)
#      [,1] [,2] [,3]
# [1,]    5    0    3
# [2,]    2    9    4

# Add the matrices.
result <- matrix1 + matrix2
cat("Result of addition","\n")
print(result)
# Result of addition 
#      [,1] [,2] [,3]
# [1,]    8   -1    5
# [2,]   11   13   10

# Subtract the matrices
result <- matrix1 - matrix2
cat("Result of subtraction","\n")
print(result)
# Result of subtraction 
#      [,1] [,2] [,3]
# [1,]   -2   -1   -1
# [2,]    7   -5    2
