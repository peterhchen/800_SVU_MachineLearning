# Elements are arranged sequentially by row.
M <- matrix(c(3:14), nrow = 4, byrow = TRUE)
print(M)
#      [,1] [,2] [,3]
# [1,]    3    4    5
# [2,]    6    7    8
# [3,]    9   10   11
# [4,]   12   13   14

# Elements are arranged sequentially by column.
N <- matrix(c(3:14), nrow = 4, byrow = FALSE)
print(N)
#      [,1] [,2] [,3]
# [1,]    3    7   11
# [2,]    4    8   12
# [3,]    5    9   13
# [4,]    6   10   14

# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))
print(P)
#      col1 col2 col3
# row1    3    4    5
# row2    6    7    8
# row3    9   10   11
# row4   12   13   14