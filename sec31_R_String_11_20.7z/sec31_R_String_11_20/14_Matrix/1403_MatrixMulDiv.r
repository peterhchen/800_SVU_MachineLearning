# Create two 2x3 matrices.
matrix1 <- matrix(c(3, 9, -1, 4, 2, 6), nrow = 2)
print(matrix1)
#      [,1] [,2] [,3]
# [1,]    3   -1    2
# [2,]    9    4    6

matrix2 <- matrix(c(5, 2, 0, 9, 3, 4), nrow = 2)
print(matrix2)
#      [,1] [,2] [,3]
# [1,]    5    0    3
# [2,]    2    9    4

# Multiply the matrices.
result <- matrix1 * matrix2
cat("Result of multiplication","\n")
print(result)
# Result of multiplication 
#      [,1] [,2] [,3]
# [1,]   15    0    6
# [2,]   18   36   24

# Divide the matrices
result <- matrix1 / matrix2
cat("Result of division","\n")
print(result)
# Result of division 
#      [,1]      [,2]      [,3]
# [1,]  0.6      -Inf 0.6666667
# [2,]  4.5 0.4444444 1.5000000