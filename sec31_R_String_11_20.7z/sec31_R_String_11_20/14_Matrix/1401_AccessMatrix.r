# Define the column and row names.
rownames = c("row1", "row2", "row3", "row4")
colnames = c("col1", "col2", "col3")

# Create the matrix.
P <- matrix(c(3:14), nrow = 4, byrow = TRUE, dimnames = list(rownames, colnames))

# Print all
print(P)
#      col1 col2 col3
# row1    3    4    5
# row2    6    7    8
# row3    9   10   11
# row4   12   13   14

# Access the element at 3rd column and 1st row.
print(P[1,3])
# [1] 5

# Access the element at 2nd column and 4th row.
print(P[4,2])
# [1] 13

# Access only the  2nd row.
print(P[2,])
# col1 col2 col3 
#    6    7    8

# Access only the 3rd column.
print(P[,3])
# row1 row2 row3 row4 
#    5    8   11   14 