# Get and print current working directory.
print(getwd())
# [1] "C:/Users/14088/Documents"

# Set current working directory.
setwd("C:/Work/SVU/800_SVU_MachineLearning/sec31_R_String_11_20")

# Get and print current working directory.
print(getwd())
# [1] "C:/Work/SVU/800_SVU_MachineLearning/sec31_R_String_11_20"