# R Packages
.libPaths()
# [1] "C:/Users/14088/Documents/R/win-library/4.0" "C:/Program Files/R/R-4.0.3/library"  

# Get All libraries
library()

#Install a New Package
# 1) Install directly from CRAN (Comprehensive R Archive Network)
# Syntax: 
# install.packages("Package Name")
# Install the package named "XML".
install.packages("XML")

#2) Install package manually
# Download and Save the package as a .zip file in a 
# suitable location in the local system.
#
#Now you can run the following command to install this package in the R environment.
# Install the package named "XML"
install.packages("C:/XML_x.xx-x.x.x.zip", repos = NULL, type = "source")

#Load Package to Library
# Syntax:
#library("package Name", lib.loc = "path to library")
# Load the package named "XML"
install.packages("C:/XML_x.xx-x.x.zip", repos = NULL, type = "source")
