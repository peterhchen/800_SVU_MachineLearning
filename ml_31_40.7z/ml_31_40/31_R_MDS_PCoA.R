# MDS and PCoA
# First, import ggplot2 library for drawing graph
library("ggplot2")
# 100 genes and 10 samples: Same as PCA
data.matrix  <- matrix (nrow=100, ncol=10)
# First 5 columns is "wt" (wild type) cell
# Second 5 columns is "ko" (knock out) cell
# Append digits without space. 
colnames(data.matrix)  <- c(
    paste ("wt", 1:5, sep=""),
    paste("ko", 1:5, sep=""))

# Create gene name from "gene1", "gene2", and etc. 
# append digit without space.

rownames (data.matrix) <- paste ("gene", 1:100, sep="")

# Assign data in matrix
for (i in 1:100) {
    wt.values <- rpois(5, lambda=sample(x=10:1000, size=1))
    ko.values <- rpois(5, lambda=sample(x=10:1000, size=1))
    data.matrix[i,] <- c(wt.values, ko.values)
}
head(data.matrix)
#       wt1 wt2 wt3 wt4 wt5 ko1 ko2 ko3 ko4 ko5
# gene1 722 728 763 780 789 457 485 513 517 517
# gene2 704 714 739 760 682 763 720 723 782 783
# gene3 413 436 463 439 418 873 855 890 905 897
# gene4 250 275 301 279 249 246 243 216 235 248
# gene5 827 844 836 824 846 509 516 565 538 536
# gene6 879 875 884 892 853 189 201 226 187 199

# just for comparison
# Transpose, scale, and center data
pca <- prcomp (t(data.matrix), scale=TRUE, center=TRUE)
pca.var <- pca$sdev^2
pca.var.per <- round(pca.var/sum(pca.var)*100, 1)
pca.var.per
#  [1] 86.1  3.5  2.7  2.1  1.7  1.4  1.2  0.7  0.7  0.0

# Gerate PCA data frame
pca.data <- data.frame(Sample=rownames (pca$x),
    X = pca$x[,1],
    Y = pca$x[,2])
pca.data
#     Sample         X          Y
# wt1    wt1 -8.637781  1.5660165
# wt2    wt2 -8.813739 -0.4340409
# wt3    wt3 -9.185510 -2.9448388
# wt4    wt4 -8.614706  1.7524144
# wt5    wt5 -8.743413  0.0985766
# ko1    ko1  8.881010 -1.5681676
# ko2    ko2  8.899883 -2.1884007
# ko3    ko3  8.931705 -0.6207066
# ko4    ko4  8.520499  1.9145862
# ko5    ko5  8.762052  2.4245609

# Create ggplot
# Left side: wt
# right side: ko
# For both wt and ko cells:
# x-axis: PC1 accounts for variation of 86.1% 
# y-axis: PC2 accouts for variation of 3.5%  
ggplot (data=pca.data, aes(x=X, y=Y, label=Sample)) +
    geom_text() + 
    xlab(paste("PC1 - ", pca.var.per[1], "%", sep="")) +
    ylab(paste("PC2 - ", pca.var.per[2], "%", sep="")) +
    theme_bw() +
    ggtitle("PCA Graph")

# Now, for MDS/PCoA
# Step 1: 
# Create a distance matrix. We do this by dist()
# t() : Tranpose matrix
# center, scale
# calculate with Euclidean method
distance.matrix <- dist (scale(t(data.matrix), center=TRUE, scale=TRUE),
    method="euclidean")

# Step 2:
# Perform multi-dimensional scaling on the distanc matrix 
# by the cmdscale() funciton.
# cmdscale (Classical Multi-Dimensional Scaleing)
# return eig (Eigen value)
# Calculate how much variation in the distance matrix each axis in the 
# final MDS plot accounts for.
# We calso get x.ret for double centered (both rows and columns are centered)
# version of the distance matrix. 
# This is useful if you want to deminstrate how to do MDS 
# using eieng() function instead of the cmdscale() function. 
mds.stuff <- cmdscale (distance.matrix, eig=TRUE, x.ret=TRUE)

# Step 3: Calculate the amount of variation each axis in the MDS plot 
# accoutns for using the eigen values.
mds.var.per <- round(mds.stuff$eig/sum(mds.stuff$eig)*100, 1)
mds.var.per
# [1] 86.1  3.5  2.7  2.1  1.7  1.4  1.2  0.7  0.7  0.0

# Step 4:
# Format the data form ggplot
mds.values <- mds.stuff$points
mds.data <- data.frame(Sample=rownames(mds.values),
    X = mds.values[,1],
    Y = mds.values[,2])
mds.data
#     Smaple         X          Y
# wt1    wt1 -8.637781  1.5660165
# wt2    wt2 -8.813739 -0.4340409
# wt3    wt3 -9.185510 -2.9448388
# wt4    wt4 -8.614706  1.7524144
# wt5    wt5 -8.743413  0.0985766
# ko1    ko1  8.881010 -1.5681676
# ko2    ko2  8.899883 -2.1884007
# ko3    ko3  8.931705 -0.6207066
# ko4    ko4  8.520499  1.9145862
# ko5    ko5  8.762052  2.4245609

# Step 5: Plot the ggplot for MDS
# wt (wild type) on the left  side
# ko (knock out) on the right side
# x-axis accounts for 91% of variation in the data.
# y-axis accounts of 2.7% varaition in the data
ggplot (data=mds.data, aes (x = X, y = Y, label=Sample))+
    geom_text() +
    theme_bw() +
    xlab(paste("MDS1 - ", mds.var.per[1], "%", sep="")) +
    ylab(paste("MDS2 - ", mds.var.per[2], "%", sep="")) +
    ggtitle("MDS plot for using Euclidean Distance")

# The PCS and MDS looks similar because we use Euclidean to 
# calculate the distance matrix.
# Now, we use different metric to calculate the dsitance matrix.
# We use the average of absolute value of the log fold change.
# for gen expresion folks, this is what ege R does when you call
# plotDMS() funciton.

# We change the Euclidean distance into the log(abs(logFC)):
# 
# First, we calcuate log2 values of the measurement for each gene.
log2.data.matrix <- log2(data.matrix)

# Since the average of absolute value of the log-fold change
# is not one of the distance metrics built into the dist() function,
# we will create our own distance matrix by hand.
# In this step, we create an empty matrix.
log2.distance.matrix <- matrix (0, 
    nrow=ncol(log2.data.matrix),
    ncol=ncol(log2.data.matrix),
    dimnames=list(colnames(log2.data.matrix),
    colnames(log2.data.matrix)))
#
# Print log2 distance
log2.distance.matrix
#     wt1 wt2 wt3 wt4 wt5 ko1 ko2 ko3 ko4 ko5
# wt1   0   0   0   0   0   0   0   0   0   0
# wt2   0   0   0   0   0   0   0   0   0   0
# wt3   0   0   0   0   0   0   0   0   0   0
# wt4   0   0   0   0   0   0   0   0   0   0
# wt5   0   0   0   0   0   0   0   0   0   0
# ko1   0   0   0   0   0   0   0   0   0   0
# ko2   0   0   0   0   0   0   0   0   0   0
# ko3   0   0   0   0   0   0   0   0   0   0
# ko4   0   0   0   0   0   0   0   0   0   0
# ko5   0   0   0   0   0   0   0   0   0   0

# Fill the marix with the average of absolute value
# of the log fold changes.
for (i in 1:ncol(log2.distance.matrix)) {
    for (j in 1:i) {
        log2.distance.matrix[i, j] <-
            mean(abs(log2.data.matrix[,i]-log2.data.matrix[,j]))
    }
}

# This is symartical martix.
log2.distance.matrix
#            wt1        wt2        wt3        wt4      wt5        ko1        ko2
# wt1 0.00000000 0.00000000 0.00000000 0.00000000 0.000000 0.00000000 0.00000000
# wt2 0.09225416 0.00000000 0.00000000 0.00000000 0.000000 0.00000000 0.00000000
# wt3 0.08618606 0.09549514 0.00000000 0.00000000 0.000000 0.00000000 0.00000000
# wt4 0.10506156 0.09514415 0.10568104 0.00000000 0.000000 0.00000000 0.00000000
# wt5 0.09425451 0.10262869 0.09125888 0.09940761 0.000000 0.00000000 0.00000000
# ko1 1.17621597 1.19637501 1.19480804 1.19810578 1.188301 0.00000000 0.00000000
# ko2 1.18794283 1.20936532 1.20499600 1.21201013 1.201995 0.09502818 0.00000000
# ko3 1.18132900 1.20450604 1.20012763 1.20487349 1.194604 0.07882194 0.09855812
# ko4 1.18939361 1.20698545 1.20699467 1.20944511 1.201049 0.08332449 0.09474809
# ko5 1.18128875 1.19808148 1.19713639 1.20238687 1.192201 0.07231204 0.09300730
#            ko3        ko4 ko5
# wt1 0.00000000 0.00000000   0
# wt2 0.00000000 0.00000000   0
# wt3 0.00000000 0.00000000   0
# wt4 0.00000000 0.00000000   0
# wt5 0.00000000 0.00000000   0
# ko1 0.00000000 0.00000000   0
# ko2 0.00000000 0.00000000   0
# ko3 0.00000000 0.00000000   0
# ko4 0.10336907 0.00000000   0
# ko5 0.08747409 0.09307762   0

# Now, perform multi-dimensional scaling on our new distance matrix.
# Here, we convert the homemade matrix into a 'true' distance matrix
# so cmdscale() knows what it is working with.
# We only need the bottom triganlge, not the whole thing.
mds.stuff <- cmdscale (as.dist(log2.distance.matrix),
    eig=TRUE,
    x.ret=TRUE)

# We calculate the amount of variation each axis in the MDS plot
# accounts for using the eigen values.
mds.var.per <- round (mds.stuff$eig/sum(mds.stuff$eig)*100, 1)

mds.var.per
# [1] 99.0  0.3  0.2  0.2  0.1  0.1  0.1  0.0  0.0  0.0
# Format data for ggplot
mds.values <- mds.stuff$points

# Fill the Data Frame.
mds.data <- data.frame (Sample=rownames (mds.values),
    X=mds.values[,1],
    Y=mds.values[,2])
# Print the data for ggplot
mds.data
#     Sample          X            Y
# wt1    wt1 -0.5831243 -0.036245357
# wt2    wt2 -0.6028389  0.041653624
# wt3    wt3 -0.6006614 -0.032520096
# wt4    wt4 -0.6048366  0.033989749
# wt5    wt5 -0.5953364 -0.007675143
# ko1    ko1  0.5909309  0.008157457
# ko2    ko2  0.6027287 -0.031351079
# ko3    ko3  0.5966974 -0.035586514
# ko4    ko4  0.6023045  0.042026018
# ko5    ko5  0.5941360  0.017551342

# Plot log Fold Change
# MDS Euclidean vs. log(abs(logFC)) vs. MDS looks similar. 
# They look similar but not the same.
# The new grap, the x-axis accounts for more variation (99.2% vs. old 86.1%)
ggplot (data=mds.data, aes(x=X, y=Y, label=Sample)) +
    geom_text() +
    theme_bw() +
    xlab(paste("MDS1 - ", mds.var.per[1], "%", sep="")) +
    ylab(paste("MDS2 - ", mds.var.per[2], "%", sep="")) +
    ggtitle ("MDS Plot using avg(logFC) as the distance")
