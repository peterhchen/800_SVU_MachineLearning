# To do Ridge, Lasso, and Elastic-Net Regression in R, we use the glmnet library.
# The glm part of glmnet, stands for Generalized Linear Model.
# The glm can be used for a Generalized Linear Model
# for Linear Regression and Logistic Regression and other models. 
# The net part of glmnet, stands for Elastic-Net.
# The glmnet used for Ridge, Lasso, and Elasttic Net.

# https://www4.stat.ncsu.edu/~post/josh/LASSO_Ridge_Elastic_Net_-_Examples.html
# random generate with seed (42)
# The seed = 42 is used for random generator to generate the same random number.
set.seed(42)

# Make up a dataset for Lasso, Ridge, and Elastic-Net Regression.
n <- 1000      # Assign sample size = 1000 
p <- 5000      # We have 5000 parameters to estimate

# Only 15 of the parameters will help us to predict the outcome 
# The remaining 4985 parameters will be random noise.
real_p <- 15  

# Now, we create a matrix called x that is full of randomly generated data.
# The matrix has 1000 rows (samples) and 5000 columns (parameters)
# The values is rnorm() is a standard normal distribution 
# We have matrix 1000 x 5000 = 5M elements
# with mean = 0, standard deviation = 1.
x <- matrix (rnorm (n*p), nrow=n, ncol=p)

# Create a vector of label (target).
# The call apply() will return a vector of 1000 values.
# https://www.rdocumentation.org/packages/base/versions/3.6.2/topics/apply
# apply (x, margin, sum)
# margin = 1 => row, margin = 2 => columns
# The sum of the first 15 [1:real_p (15)] columns in x (for each row).
# AFter sum, we add noise rnorm(1000) for 1000 sample

# This code return a vector y with sum of first 15 columns in x and a little noise.
y <- apply (x[,1:real_p], 1, sum) + rnorm (n)

# Now, we need to divide the data into training and testing set.
# We make a vector of indexes, called tainr_rows, that contains the row numbers
# of rows that will be in training set.
# The sample() function randomly selects numbers between 1 and n, 
# the number of rows in our dataset
# The sample select 0.66 x n for row numbers.
# In other words, 2/3 of data will bein Training set.
# Now, we have the indexes for the rows in the training set in train_rows.
train_rows <- sample(1:n, .66*n)
# We make new matrix, x.train, that just contains the training data.
x.train <- x[train_rows, ]
# we make Testing dataset, x.text, that contains the remaining rows.
# This is done by putting a "-" sign (all indexs - index in train_rows) in front of 
# train_rows when we select the rows from x.
x.test <- x[-train_rows, ]
# We select the training value for y
y.train <- y [train_rows]
# any index subtract index in train_rows.
y.test <- y [-train_rows]

# We will use these data to compare Ridge, Lasso, and Elastic-Net.
# We start from ridge regression: cv.glmnet()
# cv stands for "cross validation". We use cv to obtain optimal values for lambda.
# By default, cv.glmnet() uses "10-fold Cross Validation".
# The first parameter specified the trainifn set: x.train to predcit y.train.
# Note: glmnet() pass x and y separately, which is different from lm() and glm().
# type.measure is how corss-validation will be evaluated.
# It sets for mse: stands for "mean sqaured error".
# Mean sqaure error = (sum of squared error) / (sample_size)
# Note: if we use Elastic-Net Regresiom, we set this to deviance.
# Since we start from Ridge Rigression, we set alpha = 0 
# (Lambda x (1 - alpha) x Ridge )
# (Lambda x alpha x Lasso = 0)
# Lastly, we set family = "gaussian" for glmnet for Liner Regression.
# Note: If we use Logistic Regression, we set family = "binomial"
library(glmnet)
alpha0.fit <- cv.glmnet(x.train, y.train, type.measure="mse", 
  alpha=0, family="gaussian")

# cv.glmnet () will fit 
# 1) Linear Regression with 
# 2) Ridge Regression Penalty
# 3) 10-Fold Cross Validation
# to find optimal values for Lamba.
# The alpha0.fit is for aplha0 for Ridge Regression.

# We use predict() to apply aplha0.fit to the testing data.
# Lambda.1se s the value for lambda.
# Store in alpha0.fit that resulted in the simplest model, i.e., 
# the model with the fewest non-zero parameters and was within 
# 1 standard error of the lamdba has he smallest sum.
alpha0.predicted <- predict (alpha0.fit, s=alpha0.fit$lambda.1se, newx=x.test)
# Calculate the mean sqaured error
mean ((y.test - alpha0.predicted)^2)
# [1] 14.88459

#### --------  Lasso Regression Prediction ----------- #####
# Now, we try Lasso Regression with the same training/Testing set.
# Same as Ridge Regression, we use 10-Fold Cross Validation to detemrine the optimal 
# value for lambda.
# In Lasso Regression, we set alpha = 1.
# We store the model to alpha1.fit
library(glmnet)
alpha1.fit <- cv.glmnet(x.train, y.train, type.measure="mse", 
  alpha=1, family="gaussian")

# We call the predict function.
# This time, we passed in alpha1.fit and save the result in alpha1.predicted.
alpha1.predicted <- predict (alpha1.fit, s=alpha1.fit$lambda.1se, newx=x.test)

# Then, we calculate he mean sqaured error.
mean ((y.test - alpha1.predicted)^2)
# [1] 1.172819
# Lasso Regression mean = 1.17 is much smaller than Ridge Regression mean = 14.88 
# Lasso REgression is much better than Ridge Regression.

##### ---- Elastic-Net Regression -----  ########
# Now, we look ar the Elastic Net which combined the Ridge and Lasso Regression.
# Just like before, we call cv.glmnet() to deterimine optimal values for lambda.
# Only this time, we set the alpha = 0.5.
# We store the model in the alpha0.5.fit.
library(glmnet)
alpha0.5.fit <- cv.glmnet(x.train, y.train, type.measure="mse", 
  alpha=0.5, family="gaussian")

# We call the predict function.
# This time, we passed in alpha0.5.fit and save the result in alpha1.predicted.
alpha0.5.predicted <- predict (alpha0.5.fit, s=alpha0.5.fit$lambda.1se, newx=x.test)
# we calculate the mean sqaure error.
mean ((y.test - alpha0.5.predicted)^2)
# [1] 1.225528
# The Elastic-Net is a little bit larger than Lasso Regression mean = 1.17.
# So far, Lasso Regression Wins.

# Did Lasso really win? We need to try a lot of alpha for Elastic-Net.
# Create a empty list.
list.of.fits <- list()
# we use for loop to try different values for alpha.
for (i in 0:10) { # i = 0 to 10
    # alpha = 0 (Ridge), 0.1, ..., 1 (lassO)
    fit.name <- paste0 ("alpha", i / 10)  
    list.of.fits[[fit.name]] <- 
      cv.glmnet (x.train, y.train, type.measure = "mse", alpha=i/10,
      family="gaussian")
}

# Craete the empty result by daat.frame()
# resuls will store mean square error
results <- data.frame()
for (i in 0:10) { # i = 0 to 10
    # alpha = 0 (Ridge), 0.1, ..., 1 (lassO)
    fit.name <- paste0 ("alpha", i / 10) 
    # This time, we use predict function.
    # Store in predicted variable. 
    predicted <-
      predict(list.of.fits[[fit.name]],
        s=list.of.fits[[fit.name]]$lambda.1se, newx=x.test)
    mse <- mean ((y.test - predicted)^2)
    temp <- data.frame(alpha=i/10, mse=mse, fit.name=fit.name)
    # Append temp to results.
    results <- rbind (results, temp) 
}
# print out the data.
results
#    alpha       mse fit.name
# 1    0.0 15.117345   alpha0
# 2    0.1  2.256924 alpha0.1
# 3    0.2  1.503696 alpha0.2
# 4    0.3  1.346013 alpha0.3
# 5    0.4  1.287129 alpha0.4
# 6    0.5  1.252103 alpha0.5
# 7    0.6  1.236198 alpha0.6
# 8    0.7  1.212927 alpha0.7
# 9    0.8  1.209576 alpha0.8
# 10   0.9  1.172223 alpha0.9
# 11   1.0  1.184701   alpha1