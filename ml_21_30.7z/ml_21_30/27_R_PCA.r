# Generate the Dataset.
# Craete matrix of data with 10 samples and 100 genes in each samples.
data.matrix <- matrix (nrow=100, ncol=10)

# The first 5 samples are "wt" (wild type) samples.
# "wt" samples are normal, every day samples.
# The last 5 samples are "ko" (knock-out) samples.
# These are samples that are missing a gene because we knocked it out.
colnames(data.matrix) <- c(
    paste("wt", 1:5, sep=""),
    paste("ko", 1:5, sep=""))

# This is where we name the gene.
# The name is "gene1", "gene2", ..., "gene100".
rownames(data.matrix) <- paste("gene", 1:100, sep="")
# Give fake gene and fake read count.
for (i in 1:100) {
    # 1. https://www.rdocumentation.org/packages/base/versions/3.6.2/topics/sample
    #    Sample: take a sample of specified size from element of x using 
    # 2. rpois (random poisson) generates data 
    # 3. data from  x=10:1000
    #    [1]= 10, [2] = 11, ..., [991] = 1000 
    # 4. lambda=sample(x=10:1000, size=1)
    # 5. radnom sampling one data (size=1) from x[1]=10 to x[991]=1000
    # https://stat.ethz.ch/R-manual/R-devel/library/stats/html/Poisson.html
    #    generate the 5 random poison number for wt.values ()
    #    rpois(5, lambda=sample(x=10:1000, size=1))
    # Generate 5 random number fpr wt.
    wt.values <- rpois(5, lambda=sample(x=10:1000, size=1))
    # Generate 5 random number of ko
    ko.values <- rpois(5, lambda=sample(x=10:1000, size=1))
    # assign data to matrix
    data.matrix[i,] <- c(wt.values, ko.values)
}
# pirnt the data
head(data.matrix)
# Note: The samples are column and Genes are rows.
# We need to use t() funciton (transpose) to swap the data.
#       wt1 wt2 wt3 wt4 wt5 ko1 ko2 ko3 ko4 ko5
# gene1  49  37  44  34  52 191 215 178 183 184
# gene2 115 121  99 127 130 222 233 267 248 248
# gene3 541 525 572 589 534 701 804 720 805 766
# gene4 265 302 250 269 279 891 833 935 876 841
# gene5 739 723 743 779 740 617 646 659 630 607
# gene6 490 482 496 478 486 280 239 240 294 269

# We callprecomp() to do PCA on our data.
# https://www.rdocumentation.org/packages/stats/versions/3.6.2/topics/prcomp
# prcomp (Principal COmponent Analysis)
# The goal is to draw a graph that shows how the samples are related 
# (or not related) to each other
# Note:
# By default, precomp() expect the samples to be rows and the genes 
# to be columns.
# since the samples in our data matrix are columns and 
# genes (variables) are rows, we have to transpose the matrix using 
# the t() funcion.
# If we do not transpose the matrix, we will get a graph that shows 
# the genese are related to each other.
# precomp() returns three things.
# 1) x
# 2) sdev
# 3) Rotation
pca <- prcomp(t(data.matrix), scale=TRUE)

# x: contains the PCs (Principal Componnents) for drawing a graph.
#    Here we are using the first two columns in x to draw a 2-D plot
#    that ises the first two PCs.
# Remember:
# we have 10 samples and 20 PCs.
# The first PC accounts for the most variation in the original data
# (The gene expresion accross 10 samples),
# The 2nv PC accoutns for the second most variation and so on.
# To plot a 2-D PCA graph, we usually use te first 2 PCs.
# However, somestime swe use PC2 and PC3.
# We can se 5 of samples on the left graph and 
# 5 of samples on the right graph.
plot(pca$x[,1], pca$x[,2])

# We use the sqaure of sdev, which stands for "Standard Deviation",
# to calculate how much varaition in the original data each
# each principal component accounts for.
pca.var <- pca$sdev^2

# Since the percentage of variation that each PC accounts for is more 
# interesting thant the actual value, we calculate the percentages.
pca.var.per <- round(pca.var/sum(pca.var)*100, 1)

# Plot the Variation Percetnage with barplot()
# We can see PC1 accounts for almost all of the variation in the data.
barplot (pca.var.per, main="Scree Plot", xlab="Principal Component", 
ylab="Percent Variation")

# import gglplot2 to plot PCA.
library(ggplot2)

pca.data <- data.frame(Sample=rownames(pca$x),
X=pca$x[,1],
Y=pca$x[,2])

pca.data
# We have one row per sample.
# Each row has a sample ID and X/Y coodrinates for that sample.
#     Sample         X          Y
# wt1    wt1 -8.432580  0.2935132
# wt2    wt2 -8.696316 -0.5023663
# wt3    wt3 -9.027383  0.5385762
# wt4    wt4 -8.645538  1.5475167
# wt5    wt5 -8.906188 -1.9476843
# ko1    ko1  8.700789  2.5931899
# ko2    ko2  9.203695 -1.4875319
# ko3    ko3  8.758027  0.8137521
# ko4    ko4  8.756382 -3.5774696
# ko5    ko5  8.289111  1.7285040

# call for ggplot()
# 
# In the first line of plot,
# ggplot(data=pca.data, aes(x=X, y=Y, label=Sample)) 
# we pass the pca.data dataframe and tell ggplot 
# which columns contains the X and Y coordinates
# and which column has the sample labels.
# 
# geom_text () 
# The we use geom_text() to tell ggplot to the labels 
# raher thanbt dots or some other shape.
#
# xlab() and ylab()
# add the label
#
# theme_bw()
# Make background to black and white
#
# ggtile()
# Add the tttle.
ggplot(data=pca.data, aes(x=X, y=Y, label=Sample)) + 
geom_text () + 
xlab(paste("PC1 = ", pca.var.per[1], "%", sep="")) +
ylab(paste("PC2 = ", pca.var.per[2], "%", sep="")) +
theme_bw() +
ggtitle("My PCA Group")

# Lastly, we look at how to use loading scores to
# determine which genes have the largest effect on 
# where samples are plotted in the PCA plot.
#
# The prcomp() function calls the loading scores rotation.
# There are loading scores for each PC.
#
# Here, we are going to look at the loading scores for PC1.
# Since it accounts for 92% of the variation in the data.
loading_scores <- pca$rotation[,1]

# Genes that push samples to the left side of the graph
# will have large negative values and genes that push
# samples to the right will have large positive values.
# 
# Since we are interested in both sets of genes,
# we will use the abs() function to sort based on the 
# number's manitude rather than from high to low.
gene_scores <- abs (loading_scores)

# Now, we sort the magnitute pf laoding scores, 
# from high to low.
gene_score_ranked <- sort (gene_scores, decreasing=TRUE)

# Now, we get the names of the top 10 genes
# with the largest loading score magnitudes.
top_10_genes <- names (gene_score_ranked[1:10])
top_10_genes
#  [1] "gene7"  "gene19" "gene9"  "gene95" "gene51" "gene55" "gene37" "gene30"
#  [9] "gene25" "gene67"

# Lastly, we check which genes have the postive loading score.
# Show the scores with +/- sign 
#
# These positive genes loading score push the "ko" (knock out) samples 
# to the right side of the graph.
#
# Then, we see which gene have the negtive loading score
# These negative loading score pusht eh "wt" (wild type) samples to the 
# left side of the graph.
#
pca$rotation[top_10_genes, 1] 
# gene7     gene19      gene9     gene95     gene51     gene55     gene37 
# -0.1084292  0.1084167  0.1084106  0.1083871 -0.1083724  0.1083703 -0.1083642 
#     gene30     gene25     gene67 
#  0.1083624  0.1083498 -0.1083385 