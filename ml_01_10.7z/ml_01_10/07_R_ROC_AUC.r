# Assign number of samples = 100
num.samples <- 100
print('num.samples:')
num.samples
# Create 100 measurements and store them in a variable weight
# We use rnorm function to generate the random number with normal distribution.
# The mean = 172 and standard deviaiton = 29.
# mean is 172 lb of person with deviaiton 29 lb.
# Then we sort the number from low to high.
weight <- sort (rnorm (n=num.samples, mean=172, sd=29))

# rank(): fucntion to rank the weight from the lighest to heaviest.
# The lightest sample rank = 1, teh heaviest sample rank = 100.
# https://www.rdocumentation.org/packages/base/versions/3.6.2/topics/rank
# Then, sacle the ranks by 100.
# the lightest sample: 1/100 = 0.01, the heaviest one = 100/100 = 1.
# 
# Then, we use runif () to compare the scaled ranks to random number between 0 to 1.
# runif (): R-uniform random number generation 
# If the random number is smaller than the scaled rank, it is assigned to 'yes' (obese).
# If the random number is larger than the scaled rank, it is assigne to 'no' (normal) 
#
# ifesle: if (test) is true, then yes = 1, if (test) is false, then no = 0.
# The result is stored in a variable 'obese'
obese <- ifelse (test=(runif (n=num.samples) < (rank(weight)/100)), yes=1, no=0)

# print the content of obese: 0 is 'normal', 1 is 'obese'.
# The lighter samples mostly are 0s (normal) 
# and heavier samples mostly are 1s (obese).
print('obese:')
obese
# Now plot the sata.
plot (x=weight, y = obese)

# use glm() funciton to fit a logistic regression by binomial family.
# https://www.rdocumentation.org/packages/stats/versions/3.6.2/topics/glm
# https://www.statmethods.net/advstats/glm.html
# family = binomial
# link funciton = "logit"
glm.fit = glm (obese ~ weight, family=binomial)
# To draw a curve tell us the predicted probabilty 
# that an individual is obese or normal.
# glm.fit$fitted.values contains the y-axis corrdinates 
# along the curve for each sample is obese.
lines (weight, glm.fit$fitted.values)

# 1.  > install.packages()
# 2. pop up a R library coutry list: Select the country, such as, US (OR)
# 3. pop up a selection dialog: select the library "pROC".
#
# Install the Library
# 1. > library ("pROC"): It will prompt error to use "citation("pROC")
#

# We will use known classificaiton and the estimated proabilities 
# to draw an ROC curve. 
# we use roc() funciton for the pROD lubrary to draw thre ROC graph.
# 
# 1. We pass the classificaitons: obese or normal for each sample.
# 2. estiamted probabilities: glm.fit$fitted.values 
#    that each sample is obese.
# 3. plot=TRUE: Tell thr roc() fucntion to draw the graph. 
roc (obese, glm.fit$fitted.values, plot=TRUE)

# Get rid of the ugly padding on two side of the graph,
# we have to to par() funciton and muck around with graph
# parameter "s".
# Plot type "s" means "sqaured"
par(pty="s")
# plot again. Nothing change.
roc (obese, glm.fit$fitted.values, plot=TRUE)

# The x-axis is diaply from 1 to 0 for Specificity.
# We wan to cahnge from 0 to 1.
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE)

# Change the Label name.
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage")

# Change the Display Color "blue"
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="#377eb8", lwd=4)

# Change the Display Color "red"
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="red", lwd=4)

# Display Zoom
# Same the information
roc.info <- roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="red", lwd=4)

# Multiple the sensitivities * 100 and specificities * 100
roc.df <- data.frame (
    tpp=roc.info$sensitivities*100,
    fpp=(1-roc.info$specificities)*100,
    thresholds = roc.info$thresholds
    )
# Look at the first fifth row of new data frame.
head(roc.df)
# Displat the last fitth row of data frame.
tail(roc.df)
# Cut the data in 60 and 80.
roc.df [roc.df$tpp>60 & roc.df$fpp < 80,]

# Display AUC % on graph
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="red", lwd=4, print.auc=TRUE)

# Display Partial AUC % on graph
# partial.auc=c(100, 90) is based on Specificities, not 1- Specificities
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="red", lwd=4, print.auc=TRUE, print.auc.x=45, partial.auc=c(100, 90),
auc.polygon = TRUE, auc.polygon.col="#377eb8")

# Display Partial AUC % on graph
# partial.auc=c(100, 90) is based on Specificities, not 1- Specificities
# auc.polygon.col="#377eb822": Add two digit at end (22) for the transpancy.
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="red", lwd=4, print.auc=TRUE, print.auc.x=45, partial.auc=c(100, 90),
auc.polygon = TRUE, auc.polygon.col="#377eb822")

# Add Random Foreest Library
# > install.packages()
# 1. Select the "randomForeset"
# Add Library
# > library ("randomForest")
# Plot two ROC Curves
# Make two random forest classifier for the same data set obese
rf.model <- randomForest (factor (obese) ~ weight)

# Draw ROC curve for logistic regression
roc (obese, glm.fit$fitted.values, plot=TRUE, legacy.axes = TRUE,
percent=TRUE, xlab="False Positive Percentage", ylab = "True Positive Percentage",
col="#377eb8", lwd=4, print.auc=TRUE)

# plot.roc same as roc
# model data is glm.model$fitted.votes[0,1]
# print.auc.y=40 the AUC for Random Forest is print below the AUC for the Logistic Regresion.
# Because we use Random Forest, the second parameter is the number of tree 
# that voted correctly (rf.model$votes[,1]).
# RGB value is from web site.
# add = TRUE for ROC curve is added to an existing graph.
# https://rstudio-pubs-static.s3.amazonaws.com/329657_ad867511bff34a08a15233a2c9589232.html
# print.auc.y=40 so that AUC for the randoem forest is printed below the AUC for the 
# logistic regression. Do not print over than previous on print.auc.x=47
plot.roc (obese, rf.model$votes[,1], percent=TRUE, 
col="#4daf4a", lwd=4, print.auc=TRUE, add=TRUE, print.auc.y=40)

# Draw the legend on the bottom
# http://www.sthda.com/english/wiki/add-legends-to-plots-in-r-software-the-easiest-way
legend("bottomright", legend=c("Logistic Regression", "Random Forest"), col=c("#377eb8", "#4daf4a"), lwd=4)