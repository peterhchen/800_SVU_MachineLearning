# Delete var.3
rm(var.3)
print(var.3)

# Delete all variables.
rm(list = ls())
print(ls())