# For loop
v <- LETTERS[1:4]
for (i in v) {
   print(i)
}

# [1] "A"
# [1] "B"
# [1] "C"
# [1] "D"