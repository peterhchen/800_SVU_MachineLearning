# Create a function with arguments.
new.function <- function(a, b) {
   print(a^2)
   print(a)
   print(b)
}

# Evaluate the function without supplying one of the arguments.
new.function(6)
# [1] 36
# [1] 6
# Error in print(b) : argument "b" is missing, with no default