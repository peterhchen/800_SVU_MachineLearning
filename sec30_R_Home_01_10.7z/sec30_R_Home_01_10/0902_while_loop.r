# while loop
v <- c("Hello","while loop")
cnt <- 2

while (cnt < 7) {
   print(v)
   cnt = cnt + 1
}

# [1] "Hello"      "while loop"
# [1] "Hello"      "while loop"
# [1] "Hello"      "while loop"
# [1] "Hello"      "while loop"
# [1] "Hello"      "while loop"