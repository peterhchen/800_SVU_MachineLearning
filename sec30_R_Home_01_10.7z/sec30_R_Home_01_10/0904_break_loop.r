# break loop
v <- c("Hello","loop")
cnt <- 2

repeat {
   print(v)
   cnt <- cnt + 1
	
   if(cnt > 5) {
      break
   }
}

# [1] "Hello" "loop" 
# [1] "Hello" "loop" 
# [1] "Hello" "loop" 
# [1] "Hello" "loop" 