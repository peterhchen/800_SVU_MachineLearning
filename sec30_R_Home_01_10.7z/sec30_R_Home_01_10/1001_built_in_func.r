# Built-in Function
# Create a sequence of numbers from 32 to 44.
print(seq(32,44))

# [1] 32 33 34 35 36 37 38 39 40 41 42 43 44

# Find mean of numbers from 25 to 82.
print(mean(25:82))
# [1] 53.5

# Find sum of numbers frm 41 to 68.
print(sum(41:68))
# [1] 1526