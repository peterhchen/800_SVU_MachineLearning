# next loop
v <- LETTERS[1:6]
for (i in v) {
   
   if (i == "D") {
      next
   }
   print(i)
}

# [1] "A"
# [1] "B"
# [1] "C"
# [1] "E"
# [1] "F"