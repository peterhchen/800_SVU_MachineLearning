print(ls())
#  [1] "a"                   "apple"               "apple_colors"        "BMI"                
#  [5] "data"                "Expression"          "factor_apple"        "glm.fit"            
#  [9] "Lab"                 "list1"               "ll.null"             "ll.proposed"        
# [13] "ll.propsed"          "logistic"            "M"                   "model"              
# [17] "mouse.data"          "mouse.regression"    "multiple.regression" "num.samples"        
# [21] "obese"               "predicted.data"      "rf.model"            "roc.df"             
# [25] "roc.info"            "Size"                "Type"                "url"                
# [29] "var.1"               "var.2"               "var.3"               "var_x"  


# List the variables starting with the pattern "var".
print(ls(pattern = "var")) 
# [1] "var.1" "var.2" "var.3" "var_x"

#The variables starting with dot(.) are hidden, 
#they can be listed using "all.names = TRUE" argument to ls() function.
print(ls(all.name = TRUE))
#  [1] ".Random.seed"        "a"                   "apple"               "apple_colors"       
#  [5] "BMI"                 "data"                "Expression"          "factor_apple"       
#  [9] "glm.fit"             "Lab"                 "list1"               "ll.null"            
# [13] "ll.proposed"         "ll.propsed"          "logistic"            "M"                  
# [17] "model"               "mouse.data"          "mouse.regression"    "multiple.regression"
# [21] "num.samples"         "obese"               "predicted.data"      "rf.model"           
# [25] "roc.df"              "roc.info"            "Size"                "Type"               
# [29] "url"                 "var.1"               "var.2"               "var.3"              
# [33] "var_x"               "weight"              "Weight"             
