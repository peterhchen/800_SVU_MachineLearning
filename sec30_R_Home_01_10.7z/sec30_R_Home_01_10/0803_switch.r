# Switch
x <- switch(
   3,
   "first",
   "second",
   "third",
   "fourth"
)
print(x)
# [1] "third"