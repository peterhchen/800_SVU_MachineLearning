# > conda activate tensorflow
# > conda install R
# > R 
# or 
# > R
# > myString <- "Hello, World"
# > print (myString)
[1] "Hello, World"

# The other way with GUI
# Intall Window R
# Double click R logo.