# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec34_R_Time_41_50/44_RandomForest"
setwd(path)
print (getwd())

# Load the party package. It will automatically load other
# required packages.
library(party)
library(randomForest)

# Create the forest.
output.forest <- randomForest(nativeSpeaker ~ age + shoeSize + score, 
           data = readingSkills)

# View the forest results.
print(output.forest) 
# print(importance(fit,type = 2)) 
# Call:
#  randomForest(formula = nativeSpeaker ~ age + shoeSize + score, data = readingSkills) 
#                Type of random forest: classification
#                      Number of trees: 500
# No. of variables tried at each split: 1

#         OOB estimate of  error rate: 2%
# Confusion matrix:
#     no yes class.error
# no  98   2        0.02
# yes  2  98        0.02

# Importance of each predictor.
print(importance(output.forest,type = 2)) 
#          MeanDecreaseGini
# age              13.69068
# shoeSize         17.80320
# score            58.06361
