# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec34_R_Time_41_50/41_TimeSeries"
setwd(path)
print (getwd())

# Read Dataset that contains data on the age of death of successive kings of England
kings <- scan("http://robjhyndman.com/tsdldata/misc/kings.dat",skip=3)
# Read 42 items
kings
#  [1] 60 43 67 50 56 42 50 65 68 43 65 34 47 34 49 41 13 35 53 56 16 43 69 59 48
# [26] 59 86 55 68 51 33 49 67 77 81 67 71 81 68 70 77 56
png(file = "kingstimeseries.jpg")

plot.ts(kingstimeseries)
# Save the file.
dev.off()
