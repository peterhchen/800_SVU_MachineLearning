# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec34_R_Time_41_50/45-SurvivalAnalysis"
setwd(path)
print (getwd())

install.packages("survival")

# Load the library.
library("survival")

# Print first few rows.
print(head(pbc))
#   id time status trt      age sex ascites hepato spiders edema bili chol albumin copper alk.phos    ast trig platelet protime stage
# 1  1  400      2   1 58.76523   f       1      1       1   1.0 14.5  261    2.60    156   1718.0 137.95  172      190    12.2     4
# 2  2 4500      0   1 56.44627   f       0      1       1   0.0  1.1  302    4.14     54   7394.8 113.52   88      221    10.6     3
# 3  3 1012      2   1 70.07255   m       0      0       0   0.5  1.4  176    3.48    210    516.0  96.10   55      151    12.0     4
# 4  4 1925      2   1 54.74059   f       0      1       1   0.5  1.8  244    2.54     64   6121.8  60.63   92      183    10.3     4
# 5  5 1504      1   2 38.10541   f       0      1       1   0.0  3.4  279    3.53    143    671.0 113.15   72      136    10.9     3
# 6  6 2503      2   2 66.25873   f       0      1       0   0.0  0.8  248    3.98     50    944.0  93.00   63       NA    11.0     3

# Create the survival object. 
survfit(Surv(pbc$time,pbc$status == 2) ~ 1)
# Call: survfit(formula = Surv(pbc$time, pbc$status == 2) ~ 1)

#       n  events  median 0.95LCL 0.95UCL 
#     418     161    3395    3090    3853 

# Give the chart file a name.
png(file = "survival.png")

# Plot the graph. 
plot(survfit(Surv(pbc$time,pbc$status == 2)~1), 
    xlab = "day",
    ylab = "probability",
    main = "Primary Biliary Cirrhosis")

# Save the file.
dev.off()
