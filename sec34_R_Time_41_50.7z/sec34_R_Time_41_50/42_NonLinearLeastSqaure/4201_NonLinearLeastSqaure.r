# Setup current working directory
path <- "C:/Work/SVU/800_SVU_MachineLearning/sec34_R_Time_41_50/42_NonLinearLeastSqaure"
setwd(path)
print (getwd())

xvalues <- c(1.6,2.1,2,2.23,3.71,3.25,3.4,3.86,1.19,2.21)
yvalues <- c(5.19,7.43,6.94,8.11,18.75,14.88,16.06,19.12,3.21,7.58)

# Give the chart file a name.
png(file = "nls.png")

# Plot these values.
plot(xvalues,yvalues)

# Take the assumed values and fit into the model.
model <- nls(yvalues ~ b1*xvalues^2+b2,start = list(b1 = 1,b2 = 3))
# Formula: yvalues ~ b1 * xvalues^2 + b2
# summary
print(summary(model))
# Parameters:
#    Estimate Std. Error t value Pr(>|t|)    
# b1  1.19542    0.02503  47.764 4.08e-11 ***
# b2  1.99692    0.21663   9.218 1.55e-05 ***
# ---
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

# Residual standard error: 0.3678 on 8 degrees of freedom

# Number of iterations to convergence: 1 
# Achieved convergence tolerance: 1.082e-08

# Plot the chart with new data by fitting it to a prediction from 100 data points.
new.data <- data.frame(xvalues = seq(min(xvalues),max(xvalues),len = 100))
lines(new.data$xvalues,predict(model,newdata = new.data))

# Save the file.
dev.off()

# summary
print(summary(model))
# Get the sum of the squared residuals.
print(sum(resid(model)^2))
# [1] 1.081935
# Get the confidence intervals on the chosen values of the coefficients.
print(confint(model))
# Waiting for profiling to be done...
#        2.5%    97.5%
# b1 1.137708 1.253135
# b2 1.497364 2.496484

